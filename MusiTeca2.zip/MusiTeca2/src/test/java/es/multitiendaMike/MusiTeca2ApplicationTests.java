package es.multitiendaMike;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusiTeca2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
