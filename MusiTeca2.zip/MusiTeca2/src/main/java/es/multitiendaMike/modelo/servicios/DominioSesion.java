package es.multitiendaMike.modelo.servicios;

import org.springframework.stereotype.Service;

@Service
public class DominioSesion {
	
}
